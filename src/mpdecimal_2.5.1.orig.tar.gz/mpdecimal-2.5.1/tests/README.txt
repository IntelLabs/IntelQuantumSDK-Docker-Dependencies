

Download official tests and add the tests to the testdata directory:
====================================================================

# Unix: If wget is installed, just execute `make check` from
# the top level directory.

# Windows: See vcbuild directory.


#
# If gettests.sh or gettests.bat fails:
#
#   mkdir testdata && cp testdata_dist/* testdata
#
# Get http://speleotrove.com/decimal/dectest.zip and extract the archive
# so that the directory structure is testdata/*.decTest.
#
# Change into the top level directory, build the library, change back
# to the test directory, run:
#
#   make && ./runshort.sh
#



