Copyright
=========

|copyright|

Authors:
 * Neil Schemenauer <nas@debian.org>
 * Matthias Klose <doko@debian.org>
 * Gregor Hoffleit <flight@debian.org>
 * Josselin Mouette <joss@debian.org>
 * Joe Wreschnig <piman@debian.org>
 * Loïc Minier <lool@debian.org>
 * Scott Kitterman <scott@kitterman.com>
 * Barry Warsaw <barry@debian.org>
 * Ben Finney <ben+debian@benfinney.id.au>
 * Neil Williams <codehelp@debian.org>
 * Stefano Rivera <stefanor@debian.org>

This manual is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

This is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

A copy of the GNU General Public License version 2 is available as
:file:`/usr/share/common-licences/GPL-2` in the Debian GNU/Linux system,
or on the World Wide Web at `GNU General Public License, version 2
<https://www.gnu.org/licenses/old-licenses/gpl-2.0.html>`_.

You can also obtain it by writing to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA.
