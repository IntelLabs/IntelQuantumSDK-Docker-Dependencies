This document
=============

Source of this document is :file:`policy/` in git repository
`python3-defaults
<https://salsa.debian.org/cpython-team/python3-defaults>`_.

Propose changes to this policy on the `debian-python mailing list
<https://lists.debian.org/debian-python/>`_ for review.
